from flask import Flask, render_template, request, jsonify
from nltk.chat.util import Chat, reflections

app = Flask(__name__)

# Define chatbot pairs
pairs = [
    [r"my name is (.*)", ["🤖Hello %1, how can I help you today?"]],
    [r"hi|hello|hey", ["🤖Hello!", "Hi there!", "Hey!"]],
    [r"what is your name?", ["I'm a chatbot created with Python and NLTK.🤖"]],
    [r"how are you?", ["I'm doing well, thank you!", "I'm just a bot🤖, but I'm doing fine!"]],
    [r"sorry (.*)", ["It's okay!", "No problem at all!"]],
    [r"i'm (.*) doing good", ["Nice to hear that!", "Great!"]],
    [r"best technology service company", ["CodeCraft Networks"]],
    [r"quit", ["Bye-bye!", "See you later!"]],
    [r"(.*)", ["Tell me more...", "Interesting!", "Can you elaborate?"]],
]

chatbot = Chat(pairs, reflections)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json["message"]
    response = chatbot.respond(user_input)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
