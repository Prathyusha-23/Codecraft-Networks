from flask import Flask, render_template, request, redirect, url_for
import csv
import os
from datetime import datetime
from collections import defaultdict

app = Flask(__name__)
DATA_FILE = 'expenses.csv'

# Create CSV with headers if it doesn't exist
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Date', 'Type', 'Amount', 'Category', 'Description'])

# Home Page: Show all transactions
@app.route('/')
def index():
    transactions = []
    with open(DATA_FILE, newline='') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header
        for row in reader:
            transactions.append(row)
    return render_template('index.html', transactions=transactions)

# Add transaction: GET to show form, POST to save transaction
@app.route('/add', methods=['GET', 'POST'])
def add_transaction():
    if request.method == 'POST':
        t_type = request.form['type']
        amount = request.form['amount']
        category = request.form['category']
        description = request.form['description']
        date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        with open(DATA_FILE, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([date, t_type, amount, category, description])

        return redirect(url_for('index'))
    return render_template('add.html')

# Summary Page: Show total balance and category-wise expense summary
@app.route('/summary')
def summary():
    balance = 0.0
    category_totals = defaultdict(float)

    with open(DATA_FILE, newline='') as file:
        reader = csv.DictReader(file)
        for row in reader:
            amount = float(row['Amount'])
            if row['Type'] == 'income':
                balance += amount
            elif row['Type'] == 'expense':
                balance -= amount
                category_totals[row['Category']] += amount

    return render_template('summary.html', balance=balance, categories=category_totals)

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
